import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/userDAO")
public class userDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public userDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/testdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<user> listAllUsers() throws SQLException {
        List<user> listUser = new ArrayList<user>();        
        String sql = "SELECT * FROM User";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            String email = resultSet.getString("email");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            String password = resultSet.getString("password");
            String address = resultSet.getString("address"); 
            String card = resultSet.getString("card");
            String phone = resultSet.getString("phone");

             
            user users = new user(email,firstName, lastName, password, card, address, phone);
            listUser.add(users);
        }        
        resultSet.close();
        disconnect();        
        return listUser;
    }
    
    public List<user> listAllReq() throws SQLException {
        List<user> listReq = new ArrayList<user>();        
        String sql = "SELECT * FROM ongoingReq";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            String email = resultSet.getString("email");
            String firstName = resultSet.getString("firstName");
             
            user users = new user(email,firstName);
            listReq.add(users);
        }        
        resultSet.close();
        disconnect();        
        return listReq;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(user users) throws SQLException {
    	connect_func("root","pass1234");         
		String sql = "insert into User(email, firstName, lastName, password, address, card, phone) values (?, ?, ?, ?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, users.getEmail());
			preparedStatement.setString(2, users.getFirstName());
			preparedStatement.setString(3, users.getLastName());
			preparedStatement.setString(4, users.getPassword());
			preparedStatement.setString(5, users.getAddress());
			preparedStatement.setString(6, users.getCard());		
			preparedStatement.setString(7, users.getPhone());				

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public void insertTree(String treeName, String treeSize, String treeDist, List<InputStream> imageList) throws SQLException {
    	connect_func("root","pass1234");

		String sql = "insert into trees(treeName, treeSize, treeDistance, treeImage1, treeImage2, treeImage3) values (?, ?, ?, ?, ?, ?)";
		
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, treeName);
			preparedStatement.setString(2, treeSize);
			preparedStatement.setString(3, treeDist);
			for (int i = 0; i < 3; i++) {
	            if (i < imageList.size()) {
	                preparedStatement.setBlob(i + 4, imageList.get(i));
	            }
	        }					

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public boolean delete(String email) throws SQLException {
        String sql = "DELETE FROM User WHERE email = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, email);
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(user users) throws SQLException {
        String sql = "update User set firstName=?, lastName =?,password = ?,address=?,card =?, phone = ?";
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, users.getEmail());
		preparedStatement.setString(2, users.getFirstName());
		preparedStatement.setString(3, users.getLastName());
		preparedStatement.setString(4, users.getPassword());
		preparedStatement.setString(5, users.getAddress());
		preparedStatement.setString(6, users.getCard());		
		preparedStatement.setString(7, users.getPhone());
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public user getUser(String email) throws SQLException {
    	user user = null;
        String sql = "SELECT * FROM User WHERE email = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, email);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            String password = resultSet.getString("password");
            String card = resultSet.getString("card");
            String address = resultSet.getString("address"); 
            String phone = resultSet.getString("phone");
            user = new user(email, firstName, lastName, password, address, card,  phone);
        }
         
        resultSet.close();
        statement.close();
         
        return user;
    }
    
    public boolean checkEmail(String email) throws SQLException {
    	boolean checks = false;
    	String sql = "SELECT * FROM User WHERE email = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, email);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        System.out.println(checks);	
        
        if (resultSet.next()) {
        	checks = true;
        }
        
        System.out.println(checks);
    	return checks;
    }
    
    public boolean checkPassword(String password) throws SQLException {
    	boolean checks = false;
    	String sql = "SELECT * FROM User WHERE password = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, password);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        System.out.println(checks);	
        
        if (resultSet.next()) {
        	checks = true;
        }
        
        System.out.println(checks);
       	return checks;
    }
    
    
    
    public boolean isValid(String email, String password) throws SQLException
    {
    	String sql = "SELECT * FROM User";
    	connect_func();
    	statement = (Statement) connect.createStatement();
    	ResultSet resultSet = statement.executeQuery(sql);
    	
    	resultSet.last();
    	
    	int setSize = resultSet.getRow();
    	resultSet.beforeFirst();
    	
    	for(int i = 0; i < setSize; i++)
    	{
    		resultSet.next();
    		if(resultSet.getString("email").equals(email) && resultSet.getString("password").equals(password)) {
    			return true;
    		}		
    	}
    	return false;
    }
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"drop database if exists testdb; ",
					        "create database testdb; ",
					        "use testdb; ",
					        "drop table if exists user; ",
					        ("CREATE TABLE if not exists user( " +
					            "email VARCHAR(50) NOT NULL, " + 
					            "firstName VARCHAR(50) NOT NULL, " +
					            "lastName VARCHAR(50) NOT NULL, " +
					            "password VARCHAR(20) NOT NULL, " +
					            "address VARCHAR(100) NOT NULL, " +
					            "card VARCHAR(12) NOT NULL, "+ 
					            "phone VARCHAR(10) NOT NULL, "+ 
					            "PRIMARY KEY (email) "+"); ")
        					};
        String[] TUPLES = {("insert into user(email, firstName, lastName, password, address, card, phone)"+
        			"values ('susie@gmail.com', 'Susie ', 'Guzman', 'susie1234', '1234, whatever street, detroit, MI', '000000000001', '0000000000'),"+
			    		 	"('don@gmail.com', 'Don', 'Cummings','don123', '1000, hi street, MO','000000000002', '0000000000'),"+
			    	 	 	"('margarita@gmail.com', 'Margarita', 'Lawson','margarita1234', '1234, ivan street, tata, CO', '000000000003', '0000000000'),"+
			    		 	"('jo@gmail.com', 'Jo', 'Brady','jo1234', '3214, marko street, brat, DU', '000000000004', '0000000000'),"+
			    		 	"('wallace@gmail.com', 'Wallace', 'Moore','wallace1234', '4500, frey street, sestra, MI','000000000005', '0000000000'),"+
			    		 	"('amelia@gmail.com', 'Amelia', 'Phillips','amelia1234', '1245, m8s street, baka, IL', '000000000006', '0000000000'),"+
			    			"('sophie@gmail.com', 'Sophie', 'Pierce','sophie1234', '2468, yolos street, ides, CM','000000000007', '0000000000'),"+
			    			"('angelo@gmail.com', 'Angelo', 'Francis','angelo1234', '4680, egypt street, lolas, DT','000000000008', '0000000000'),"+
			    			"('rudy@gmail.com', 'Rudy', 'Smith','rudy1234', '1234, sign street, amo ne tu, MH','000000000009', '0000000000'),"+
			    			"('david', 'David', 'Smith','david1234', '0981, snoop street, kojik, HW','000000000010', '0000000000'),"+
			    			"('root', 'default', 'default','pass1234','0000 ','000000000011','0000000000');")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}
